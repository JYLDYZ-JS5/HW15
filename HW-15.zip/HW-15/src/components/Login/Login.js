//ЭТО ВЕРСИЯ С PASSWORD REDUCE
//  А ВЕРСИЯ СО ВСЕМИ ЧЕТЫРМЯ  внизу


import React, { useState } from 'react'
import Card from '../UI/Card/Card'
import classes from './Login.module.css'
import Button from '../UI/Button/Button'
import { useEffect } from 'react'
import { useReducer } from 'react'

//debouncing
// --------------------------------------------------------------------------------
function emailReducer(prevState, action) {
  if (action.type === 'User_Input') {
    return {
      value: action.value,
      isValid: action.value.includes('@'),
    }
  }
  if (action.action === 'INPUT_ONBLUR') {
    return {
      value: prevState.value,
      isValid: prevState.value.includes('@'),
    }
  }
  return {
    ...prevState, //если бул жерге value:'' десем onBlur кылганда очуп кеттат
  }
}
// -------------------------------------------------------------------------------------

function passwordReducer(prevState, action) {
  if (action.type === 'PASSWORD.VALUE') {
    return {
      passwordValue: action.value,
      isPassword: action.value,
    }
  }
  if (action.action === 'PASSWORD_ONBLUR') {
    return {
      passwordValue: prevState.value,
      isPassword: prevState.value,
    }
  }
  return {
    ...prevState,
  }
}
// -------------------------------------------------------------------------------------

const Login = (props) => {
  const [emailState, dispatchEmail] = useReducer(emailReducer, {
    isValid: undefined,
    value: '',
  })
  const [passwordState, dispatchPassword] = useReducer(passwordReducer, {
    passwordValue: '',
    isPassword: undefined,
  })





  const [formIsValid, setFormIsValid] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      setFormIsValid(emailState.value.includes('@'))
    }, 500)
    //clean up function
    return () => {
      clearTimeout(timer)
    }
  }, [emailState, passwordState])

  
  // -------------------------------------------------------------------------------
  const emailChangeHandler = (event) => {
    dispatchEmail({ type: 'User_Input', value: event.target.value })
  }

  const passwordChangeHandler = (event) => {
    dispatchPassword({ type: 'PASSWORD.VALUE', value: event.target.value })
  }

  const validateEmailHandler = () => {
    //функция которая записывается в onBlur
    dispatchEmail({ type: 'INPUT_ONBLUR' })
  }

  const validatePasswordHandler = () => {
    //функция которая записывается в onBlur
    dispatchPassword({ type: 'PASSWORD_ONBLUR' }) //Пароль должен состоять из более 6 символов
  }

  // -----------------------------------------------------------------------------

  const submitHandler = (event) => {
    //сабмиттин функциясы
    event.preventDefault() //каждый раз обновление болбосун деп
    props.onLogin(emailState.value, passwordState.value) //пропстон функция келет и аргументке ушулар берилип сабмитте ушул функция журот
  }

  return (
    <Card className={classes.login}>
      <form onSubmit={submitHandler}>
        <div
          className={`${classes.control} ${
            emailState.isValid === false ? classes.invalid : '' //эгерде emailIsValid текшеруудон отпой тоесть @жок болсо invalid класс кошулат
          }`}
        >
          <label htmlFor="email">E-Mail</label>
          <input
            type="email"
            id="email"
            value={emailState.value}
            onChange={emailChangeHandler}
            onBlur={validateEmailHandler} //это фокусту текшерип турат и ошого жараша цвет озгортот
          />
        </div>
        <div
          className={`${classes.control} ${
            passwordState.isPassword === false ? classes.invalid : '' //эгерде passwordIsValid текшеруудон отпой тоесть lenght<6 болсо invalid класс кошулат
          }`}
        >
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={passwordState.passwordValue}
            onChange={passwordChangeHandler}
            onBlur={validatePasswordHandler}
          />
        </div>
        <div className={classes.actions}>
          <Button type="submit" className={classes.btn} disabled={!formIsValid}>
            Login
          </Button>
        </div>
      </form>
    </Card>
  )
}

export default Login










// --------------------------------------------------------------------------------

// import Card from '../UI/Card/Card'
// import classes from './Login.module.css'
// import Button from '../UI/Button/Button'
// import { useReducer } from 'react'
// // -------------------------------------------------------------------------------------

// function formReduce(prevState, action) {
//   if (action.type === 'PASSWORD_VALUE') {
//     return {
//       passwordValue: action.passwordValue,
//       isPasswordValue: action.passwordValue,
//     }
//   }
//   if (action.action === 'PASSWORD_ONBLUR') {
//     return {
//       passwordValue: prevState.passwordValue,
//       isPasswordValue: prevState.passwordValue,
//     }
//   }
//   if (action.type === 'EMAIL_VALUE') {
//     return {
//       emailValue: action.value,
//       isEmailValue: action.value.includes('@'),
//     }
//   }
//   if (action.action === 'INPUT_ONBLUR') {
//     return {
//       emailValue: prevState.value,
//       isEmailValue: prevState.value.includes('@'),
//     }
//   }
  
//   return {
//     ...prevState,   //если бул жерге value:'' десем onBlur кылганда очуп кеттат
//   }
// }
// // -------------------------------------------------------------------------------------

// const Login4 = (props) => {
//   const [formState, dispatchForm] = useReducer(formReduce, {
//     emailValue: undefined,
//     isEmailValue: false,
//     passwordValue: undefined,
//     isPasswordValue: false,
   
//   })

//   // -------------------------------------------------------------------------------
//   const emailChangeHandler = (event) => {
//     dispatchForm({ type: 'EMAIL_VALUE', value: event.target.value })
//   }

//   const passwordChangeHandler = (event) => {
//     dispatchForm({ type: 'PASSWORD_VALUE', passwordValue: event.target.value })
//   }
  
//   const validateEmailHandler = () => {
//     //функция которая записывается в onBlur
//     dispatchForm({ type: 'INPUT_ONBLUR' })
//   }

//   const validatePasswordHandler = () => {
//     //функция которая записывается в onBlur
//     dispatchForm({ type: 'PASSWORD_ONBLUR' }) //Пароль должен состоять из более 6 символов
//   }

//   // -----------------------------------------------------------------------------
//   const value=formState.value
//   const valuepass=formState.passwordValue

//   const submitHandler = (event) => {
//     //сабмиттин функциясы
//     event.preventDefault() ;
//     props.onLogin(value,valuepass) 
//     //пропстон функция келет и аргументке ушулар берилип сабмитте ушул функция журот
//     console.log(value  + valuepass);
//   }
//   // -------------------------------------------------------------------------------
 

//   return (
//     <Card className={classes.login}>
//       <form onSubmit={submitHandler}>
//         <div
//           className={`${classes.control} ${
//             formState.isEmailValue === false ? classes.invalid : '' //эгерде emailIsValid текшеруудон отпой тоесть @жок болсо invalid класс кошулат
//           }`}
//         >
//           <label htmlFor="email">E-Mail</label>
//           <input
//             type="email"
//             id="email"
//             value={value}
//             onChange={emailChangeHandler}
//             onBlur={validateEmailHandler} //это фокусту текшерип турат и ошого жараша цвет озгортот
//           />
//         </div>
//         <div
//           className={`${classes.control} ${
//             formState.isPasswordValue === false ? classes.invalid : '' //эгерде passwordIsValid текшеруудон отпой тоесть lenght<6 болсо invalid класс кошулат
//           }`}
//         >
//           <label htmlFor="password">Password</label>
//           <input
//             type="password"
//             id="password"
//             value={valuepass}
//             onChange={passwordChangeHandler}
//             onBlur={validatePasswordHandler}
//           />
//         </div>
//         <div className={classes.actions}>
//           <Button
//             type="submit"
//             className={classes.btn}
           
//           >
//             Login
//           </Button>
//         </div>
//       </form>
//     </Card>
//   )
// }

// export default Login4

import { useState, useEffect } from 'react' //импортируем useEffect
import Login from './components/Login/Login'
// import Login4 from './components/Login/Login_4'
import Home from './components/Home/Home'
import MainHeader from './components/MainHeader/MainHeader'


function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  useEffect(() => {
    const stored = localStorage.getItem('isLoggedIn')
    if (stored === '1') {
      setIsLoggedIn(true)
    }
  }, [])

  const loginHandler = async (email, password) => {
    // We should of course check email and password
    // But it's just a dummy/ demo anyways
    localStorage.setItem(email, password)
    setIsLoggedIn(true)
  }

  const logoutHandler = () => {
    localStorage.removeItem('isLoggedIn')
    setIsLoggedIn(false)
  }

  return (
    <>
      <MainHeader isAuthenticated={isLoggedIn} onLogout={logoutHandler} />
      <main>
        {!isLoggedIn && <Login onLogin={loginHandler} />} importтон да комменттен чыгарып алыныз=)  
        {/* {!isLoggedIn && <Login4 onLogin={loginHandler} />} */}
        {isLoggedIn && <Home onLogout={logoutHandler} />}
      </main>
    </>
  )
}

export default App
